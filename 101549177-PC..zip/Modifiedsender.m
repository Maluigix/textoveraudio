%********Text-to-binary converter/sender module****************************************************
% This should be run on one machine while the Audiorecorder is run on
% another.
% Description:
% The basic text to binary conversion is performed, then the outputted
% binary bit stream is used to modulate a carrier tone to either play or
% not play over a specified time which can them be converted back into text
% by the audio recorder
% 
% Developed by:
% Rhys Baldwin and Rory Fahey 
% with Swinburne University.
% 
% Date:
% 23/05/2018
% 
% 
% *************************************************************************
while true
    %Converts inputted text to a usable binary output
    freq=900;
    n = 200;% setting for samples / bit 
    %We have found 200 is the lowest samples/bit that still reliably sends
 %information

    prompt = 'Type some text: (''x'' ends function)\n';%prompt
    string = input(prompt,'s');%input
    if string == 'x'
        break;
    end
    
    bin_str = dec2bin(string,8);%convert to binary

    bin_str = reshape(bin_str', [1, numel(bin_str)]);%makes one long line of binary instead of matrix

    bin_str = logical(bin_str - 48);%changes to logical array

    delay16bit=zeros(1,16); %syncronises recording time with the audio recorder
    
    syncpulse= (ones(1,round((800/n)*4))); % Adjusts the initial pulse (to start the reciever recording) depending on n
    %for n=800, 1 1 1 1 
    bin_str= [delay16bit syncpulse delay16bit bin_str delay16bit];%for sync and delays

    for_kron = ones(1,n);%sets up array for use with kronecker tensor product
    out = kron(bin_str,for_kron);%kronecker tensor product, (stretches binary code)

    q=size(out);%don't really need this, shows up in 'values' calculation below


    amp=1; %amplitude
    %fs= 8192;  % sampling frequency
    fs= 8000;  % new sampling frequency

    values= 1/fs:1/fs:(((q(1,2))/fs));
    a=amp*sin(2*pi*freq*values);
    a=a.*out;
    %sound(a)
%     save('a.mat','a')
%     filename = 'a.wav';
%     audiowrite(filename,a,fs);
%     [a,fs] = audioread(filename);
    sound(a,fs)
%     wait(length(a)/8000)
    
end
save('a.mat','a')
filename = 'a.wav';
audiowrite(filename,a,fs);
% [a,fs] = audioread(filename);
% sound(a,fs)
% recObj = audiorecorder;
% recordblocking(recObj, 3);
% y = getaudiodata(recObj);
plot(a)