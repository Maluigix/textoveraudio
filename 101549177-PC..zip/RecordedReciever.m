%********Audio-to-text converter****************************************************
% The recorded reciever needs to be run and open concurrent with the audio
% recorder. 
% Description:
% A function that when called upon recieves amplitude values from the recieved audio and converts to binary
% and finally back to text.
% 
% Developed by:
% Rhys Baldwin and Rory Fahey 
% with Swinburne University.
% 
% Date:
% 23/05/2018
% 
% 
% *************************************************************************
function [str] = RecordedReciever(j)
    j=abs(j); %corrects to only positive amplitudes
    n = 200; %bit_time; % average every n values
    b = (arrayfun(@(i) mean(j(i:i+n-1)),1:n:length(j)-n+1)); % the averaged vector which removes the bits/sample multiplication

    div8=rem(length(b),8);  %just incase not divisable by 8
    if div8 ~= 0      %Ensures that the conversion back to text is accurate with 8 bits per character
        div8= zeros(1,8-div8); 
        b=cat(2,b,div8);
    end

        I=b<mean(b); % forces values less than the mean amplitude to be zero and values greater are one. 
        J=b>mean(b);% Allows for variation in input amplitudes but creates only 0 and 1 as an output
    b(I)=0;
    b(J)=1;
    str = char(bin2dec(reshape(char(b+'0'), 8,[]).'))'; %Completes the conversion of binary back to text
    fprintf('Message; %s\nMessage Length; %i characters\n',str,(length(str))) % displays the message in its entirety 
    % Addionally displays the character length for analysis purposes
end